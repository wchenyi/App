<h1 align="center">
  <img src="https://github.com/Dreamacro/clash/raw/master/docs/logo.png" alt="Clash" width="200">
  <br>
  ClashA
  <br>
</h1>

<h4 align="center">An Android GUI for Clash.</h4>

### ClashA will be deprecated soon. For a Clash GUI on Android in active development, use **Clash for Android** developed by Kr328 instead, [Telegram Channel](https://t.me/clash_for_android_channel).

ClashA final version: 0.0.3+

### Keywords and Useful Links
- Clash : A multi-platform & rule-base tunnel, [Github](https://github.com/Dreamacro/clash)
- ClashX for Mac : A GUI of Clash on macOS, [Github](https://github.com/yichengchen/clashX)
- Clash for Windows :  a GUI of Clash on Windows, [Github](https://raw.githubusercontent.com/Fndroid/clash_for_windows_pkg)


### Build

#### Build Dependencies

* JDK 1.8
* Android SDK
  - Android NDK
#### Steps
* Clone the repo using `git clone --recurse-submodules <repo>` or update submodules using `git submodule update --init --recursive`
* Build it using Android Studio or gradle script

